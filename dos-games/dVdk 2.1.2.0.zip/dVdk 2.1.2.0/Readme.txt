------------------------------------------------------------------------------
dVDK 2.1
by Dwar
ProGamerCity.net
------------------------------------------------------------------------------

1. Description
--------------
Tool for manipulating virtual disk with extension vdk. These resources are used by Requiem and Ragnarok 2 Online.

2. System Requirements
This program runs under OS Win

3. How to
For any additional information please refer to 
http://www.progamercity.net/

